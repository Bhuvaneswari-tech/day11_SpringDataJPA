package com.example.collegemanagment.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.collegemanagment.entity.Course;
import com.example.collegemanagment.entity.Department;
import com.example.collegemanagment.entity.Instructor;
import com.example.collegemanagment.entity.Student;
import com.example.collegemanagment.repository.CourseRepository;
import com.example.collegemanagment.repository.DepartmentRepository;
import com.example.collegemanagment.repository.InstructorRepository;
import com.example.collegemanagment.repository.StudentRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ApiController {
	
	@Autowired
	private StudentRepository studentRepo;
	
	@Autowired
	private CourseRepository courseRepo;
	
	@Autowired
	private InstructorRepository instructorRepo;
	
	@Autowired
	private DepartmentRepository deptRepo;
	
	//Department
	
	@PostMapping("/departments")
    public Department addDepartment(@RequestBody Department d) {
        return deptRepo.save(d);
    }

    @GetMapping("/departments")
    public List<Department> getDepartments() {
        return deptRepo.findAll();
    }

    @GetMapping("/departments/{id}")
    public Optional<Department> getDepartmentById(@PathVariable long id) {
        return deptRepo.findById(id);
    }
    
    @PutMapping("/departments/{id}")
    public Department updateDepartment(@PathVariable long id, @RequestBody Department d) {
       d.setId(id);
        return deptRepo.save(d);
    }

    @DeleteMapping("/departments/{id}")
    public void deleteDepartment(@PathVariable long id) {
        deptRepo.deleteById(id);
    }
    
    //Instructor
    
    @PostMapping("/instructors")
    public Instructor addInstructor(@RequestBody Instructor i) {
        return instructorRepo.save(i);
    }

    @GetMapping("/instructors")
    public List<Instructor> getInstructors() {
        return instructorRepo.findAll();
    }

    @GetMapping("/instructors/{id}")
    public Optional<Instructor> getInstructorById(@PathVariable long id) {
        return instructorRepo.findById(id);
    }

    @PutMapping("/instructors/{id}")
    public Instructor updateInstructor(@PathVariable long id, @RequestBody Instructor i) {
        i.setId(id);
        return instructorRepo.save(i);
    }

    @DeleteMapping("/instructors/{id}")
    public void deleteInstructor(@PathVariable long id) {
        instructorRepo.deleteById(id);
    }

    // --------------------- COURSE ---------------------

    @PostMapping("/courses")
    public Course addCourse(@RequestBody Course c) {
        return courseRepo.save(c);
    }

    @GetMapping("/courses")
    public List<Course> getCourses() {
        return courseRepo.findAll();
    }

    @GetMapping("/courses/{id}")
    public Optional<Course> getCourseById(@PathVariable long id) {
        return courseRepo.findById(id);
    }

    @PutMapping("/courses/{id}")
    public Course updateCourse(@PathVariable long id, @RequestBody Course c) {
        c.setId(id);
        return courseRepo.save(c);
    }

    @DeleteMapping("/courses/{id}")
    public void deleteCourse(@PathVariable long id) {
        courseRepo.deleteById(id);
    }

    // --------------------- STUDENT ---------------------

    @PostMapping("/students")
    public Student addStudent(@RequestBody Student s) {
        return studentRepo.save(s);
    }

    @GetMapping("/students")
    public List<Student> getStudents() {
        return studentRepo.findAll();
    }

    @GetMapping("/students/{id}")
    public Optional<Student> getStudentById(@PathVariable long id) {
        return studentRepo.findById(id);
    }

    @PutMapping("/students/{id}")
    public Student updateStudent(@PathVariable long id, @RequestBody Student s) {
        s.setId(id);
        return studentRepo.save(s);
    }

    @DeleteMapping("/students/{id}")
    public void deleteStudent(@PathVariable long id) {
        studentRepo.deleteById(id);
    }
    
}
