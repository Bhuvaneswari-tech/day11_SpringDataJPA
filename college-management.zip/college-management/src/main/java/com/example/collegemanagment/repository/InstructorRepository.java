package com.example.collegemanagment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.collegemanagment.entity.Instructor;

public interface InstructorRepository extends JpaRepository<Instructor, Long>{

}
