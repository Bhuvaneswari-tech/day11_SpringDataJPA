package com.example.springjpademo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.*;

import com.example.springjpademo.entity.Department;
import com.example.springjpademo.entity.Employee;
import com.example.springjpademo.repository.DepartmentRepository;
import com.example.springjpademo.repository.EmployeeRepository;

@RestController
@RequestMapping("/api")
public class ApiController {

	@Autowired
	private DepartmentRepository departmentRepo;
	
	@Autowired
	private EmployeeRepository employeeRepo;
	
	//Department Endpoints
	
	@PostMapping("/departments")
	public Department addDepartment(@RequestBody Department department) {
		return departmentRepo.save(department);
	}
	
	@GetMapping("/departments")
	public List<Department> getDepartments(){
		return departmentRepo.findAll();
	}
	
	@GetMapping("/departments/{id}")
	public Department getDepartment(@PathVariable Long id) {
		return departmentRepo.findById(id).orElse(null);
	}
	
	//Employee Endpoints
	
	@PostMapping("/employees")
	public Employee addEmployee(@RequestBody Employee employee) {
		return employeeRepo.save(employee);
	}
	
	@GetMapping("/employees")
	public List<Employee> getEmployees(){
		return employeeRepo.findAll();
	}
	
	@GetMapping("/employees/{id}")
	public Employee getEmployee(@PathVariable Long id) {
		return employeeRepo.findById(id).orElse(null);
	}
	
	@PutMapping("/employees/{id}")
	public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee newEmp) {
		return employeeRepo.findById(id).map(emp ->{
			emp.setName(newEmp.getName());
			emp.setEmail(newEmp.getEmail());
			emp.setDepartment(newEmp.getDepartment());
			return employeeRepo.save(emp);
		}).orElse(null);
	}
	
	@DeleteMapping("/employees/{id}")
	public String deleteEmployee(@PathVariable Long id) {
		employeeRepo.deleteById(id);
		return "Deleted successfully";
	}
	
}
