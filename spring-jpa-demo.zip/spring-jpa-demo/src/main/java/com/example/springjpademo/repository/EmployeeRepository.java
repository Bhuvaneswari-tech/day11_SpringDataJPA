package com.example.springjpademo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springjpademo.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long>{

}
